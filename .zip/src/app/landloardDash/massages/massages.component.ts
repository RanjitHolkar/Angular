import { Component, OnInit ,Renderer} from '@angular/core';
import { LandlordService } from '../../_services/landlord.service';
import { Router } from '@angular/router';
import { Url } from '../../mygloabal';

declare var $:any;
@Component({
  selector: 'app-massages',
  templateUrl: './massages.component.html',
  styleUrls: ['./massages.component.css']
})

export class MassagesComponent implements OnInit {
  tenantDetails:any;
  tenantSubject:any;
  intrval:any;
  chat_msg:any;
  sendbutton:any;
  subject_id:any;
  tenant_id:any;
  msg:any;
  landlord_details:any;
  url=Url;
  tenant_details:any;
  subject_name:any;
  constructor(private render:Renderer,private _landlordServices:LandlordService,private route:Router) { }

  ngOnInit() {
  this.sendbutton=false;
    this._landlordServices.getSenderName().subscribe((data)=>{
      this.tenantDetails=data['sender_name'];
      this.landlord_details=data['landlord_details'];
      console.log(data);
      // $(".singleCommentDivMain").animate({ scrollTop: $(document).height() }, "slow");
      // return false;
    //   var divScrollTop = $('.singleCommentDivMain').scrollTop();
    //   // //var idNumber = $("#idNumber").val();
     
    //   // var targetElem = $(".singleCommentDivMain");
    //   // var targetOffset = targetElem.offset();

    // $('.singleCommentDivMain').scrollTop(divScrollTop);
      // $(".singleCommentDivMain").animate({ scrollTop: $('.singleCommentDivMain').height() });
      //   return false;
    //   var messageBody = document.querySelector('.singleCommentDivMain');
    //  messageBody.scrollTop = messageBody.scrollHeight - messageBody.clientHeight;
    //   // var chatHistory =$('.singleCommentDivMain');
    //   $('.singleCommentDivMain').scrollTop =$('.singleCommentDivMain').scrollHeight;

      // $('#singleCommentDivMain').scrollTop($('#singleCommentDivMain')[400].scrollHeight);
    })
  }

  showLandlordMsg(sub_id,subject)
  {
    //  $('.singleCommentDivMain').scrollTop($(document).height());
    // $( ".singleCommentDivMain" ).scrollTop( 300 );
    // var objDiv = document.getElementById(".singleCommentDivMain");
    // objDiv.scrollTop = objDiv.scrollHeight;
      // $('.singleCommentDivMain').scrollTop += 10000;

    // html.
    $(".singleCommentDivMain").animate({ scrollTop: $(document).height() }, 'slow');
    this.subject_name=subject;
    this.subject_id=sub_id;
    this.intrval=false;
    this._landlordServices.getTenantMessage(sub_id).subscribe((data)=>{
    this.chat_msg=data['messages'];
    this.tenant_details=data['tenant_details'];
    console.log(data);
     })
     this.intrval=true;
     $('#landlordMessage').modal('show');
     const inter =setInterval(() => {
      if(!this.intrval && this.route.url !='/messages' ) {
       clearInterval(inter);
      }
      this._landlordServices.getTenantMessage(this.subject_id).subscribe((data)=>{
      this.chat_msg=data['messages'];
      this.tenant_details=data['tenant_details'];
      console.log(data);
     })
     }, 2000);
  
  }

  public listClick(event:any,tenant_id) {
    this.tenant_id=tenant_id;
    event.preventDefault();
    $("h5").removeClass('activeText');
    this.render.setElementClass(event.target, "activeText", true);
    this._landlordServices.getTenantsubject(tenant_id).subscribe((data)=>{
     this.tenantSubject=data;
     const inter =setInterval(() => {
       if(this.route.url !='/messages') {
        clearInterval(inter);
       }
       this._landlordServices.getTenantsubject(tenant_id).subscribe((data)=>{
        this.tenantSubject=data;
       });
      }, 2000);
    })
    
    
  }
  StopInterval()
  {
    this.intrval=false;
  }
  sendLandTenantMsg(msg)
  {
    var formData=new FormData();

    formData.append('message',msg);
    formData.append('subject_id',this.subject_id);
    formData.append('tenant_id',this.tenant_id);
    this._landlordServices.saveLandMsg(formData).subscribe((data)=>{ 
      console.log(data);
      this.showLandlordMsg(this.subject_id,this.subject_name);
     this.msg='';
      // this.showAllMessage(this.subject_id,this.subject);
      // this.msg='';
      })

  }
  sendComment(event)
  {
     if(event.data !='')
     {
       this.sendbutton=true;
     }else{
       this.sendbutton=false;
     }
  }
  // public showLandlordMsg(sub_id)
  // {

  // }

}
