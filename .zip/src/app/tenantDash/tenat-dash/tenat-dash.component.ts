import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenat-dash',
  templateUrl: './tenat-dash.component.html',
  styleUrls: ['./tenat-dash.component.css']
})
export class TenatDashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
