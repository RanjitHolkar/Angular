import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenant-payrent',
  templateUrl: './tenant-payrent.component.html',
  styleUrls: ['./tenant-payrent.component.css']
})
export class TenantPayrentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  
  }

}
