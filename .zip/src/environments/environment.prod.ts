export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDRaDs5tElJUbOHZ_XLOElT-FILYxqIM0A",
    authDomain: "rental-property-mgmt.firebaseapp.com",
    databaseURL: "https://rental-property-mgmt.firebaseio.com",
    projectId: "rental-property-mgmt",
    storageBucket: "rental-property-mgmt.appspot.com",
    messagingSenderId: "569425161133"
  },
};
