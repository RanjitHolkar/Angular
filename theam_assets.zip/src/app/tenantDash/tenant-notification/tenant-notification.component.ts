import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenant-notification',
  templateUrl: './tenant-notification.component.html',
  styleUrls: ['./tenant-notification.component.css']
})
export class TenantNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
