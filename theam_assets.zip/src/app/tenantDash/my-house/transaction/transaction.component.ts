import { Component, OnInit } from '@angular/core';
import { TenantService} from '../../../_services/tenant.service'

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
public in_progress_payment:any;
public transactionHistory:any;
public unitData:any;
public unit_id:any;
public landDetails:any;
public land_id:any;
public tenantPrfilePhoto:any;


  constructor(private tenantService:TenantService) { }

  ngOnInit() {

    this.tenantService.getTransactionDetails().subscribe((data)=>{
      console.log(data);
    this.in_progress_payment=data['in_progress_payment'];
    this.transactionHistory=data['transaction_data'];
    this.unitData=data['unit_data'][0];
    this.unit_id=this.unitData['id'];
    this.landDetails=data['landlord_details'];
    this.land_id=this.landDetails['id'];
    this.tenantPrfilePhoto=this.unitData['profilephoto'];
    });
  }

}
