import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenant-security',
  templateUrl: './tenant-security.component.html',
  styleUrls: ['./tenant-security.component.css']
})
export class TenantSecurityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
