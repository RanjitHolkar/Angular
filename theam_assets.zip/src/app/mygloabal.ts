'use strict';
export const BaseUrl="http://192.168.100.22/property_management/api/";
export const Url="http://192.168.100.22/property_management/";
 export const baseurl="http://192.168.100.22/property_management/requestapi/";

// export const Url="http://portfolio.theaxontech.com/CI/property_management/php_server/";
// export const BaseUrl="http://portfolio.theaxontech.com/CI/property_management/php_server/api/";
//  export const baseurl="http://portfolio.theaxontech.com/CI/property_management/php_server/requestapi/";


//export const BaseUrl="php_server/api/"; 