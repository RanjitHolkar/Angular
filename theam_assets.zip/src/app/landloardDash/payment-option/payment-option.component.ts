import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-option',
  templateUrl: './payment-option.component.html',
  styleUrls: ['./payment-option.component.css']
})
export class PaymentOptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
